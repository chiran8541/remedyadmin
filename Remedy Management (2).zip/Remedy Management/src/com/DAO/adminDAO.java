package com.DAO;

import java.util.List;

public interface adminDAO {
	public List<String> getAllId();
}
